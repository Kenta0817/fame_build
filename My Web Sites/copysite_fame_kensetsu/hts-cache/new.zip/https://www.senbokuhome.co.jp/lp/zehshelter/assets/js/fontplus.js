jQuery(function($) {

   FONTPLUS.setFonts([
      'ゴシックMB101 M',
      'ゴシックMB101 B'
  ]);

      // 'FOT-筑紫明朝 Pr6 L',
      // 'FOT-筑紫明朝 Pr6 RB',
      // 'FOT-筑紫明朝 Pr6 M',
      // 'FOT-筑紫明朝 Pr6 D',
      // 'FOT-筑紫ゴシック Pr5N L',
      // 'FOT-筑紫ゴシック Pr5N M',
      // 'FOT-筑紫ゴシック Pr5N D',
      // 'FOT-筑紫ゴシック Pro RB',
      // 'FOT-筑紫ゴシック Pro D',
      // 'FOT-筑紫ゴシック Pro B'

  
  FONTPLUS.attachCompleteEvent(function(){ 
    //読み込み完了時の処理 
    //$('.go-l, .go-r, .go-m, .go-b, .go-d, .go-e, .go-h, .marugo-l, .min-l, .min-r, .min-m, .min-b, .min-d').css('opacity','1'); 
  }) 


});
