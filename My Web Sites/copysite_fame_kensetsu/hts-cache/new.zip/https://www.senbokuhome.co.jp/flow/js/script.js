$(function() {

$('#arc').arctext({radius: 70});

});
